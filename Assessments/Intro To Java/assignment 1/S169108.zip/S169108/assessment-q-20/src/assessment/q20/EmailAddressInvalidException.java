package assessment.q20;

public class EmailAddressInvalidException extends Exception {

	private static final long serialVersionUID = 1L;

}
